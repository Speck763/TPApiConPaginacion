package com.example.demo.services;


import com.example.demo.entities.Autor;

public interface AutorService extends BaseService<Autor,Long> {
}