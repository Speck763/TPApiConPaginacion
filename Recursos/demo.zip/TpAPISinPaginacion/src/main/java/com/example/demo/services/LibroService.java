package com.example.demo.services;

import com.example.demo.entities.Libro;

public interface LibroService extends BaseService<Libro,Long>{
}