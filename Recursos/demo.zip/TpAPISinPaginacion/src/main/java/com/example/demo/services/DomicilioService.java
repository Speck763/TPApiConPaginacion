package com.example.demo.services;


import com.example.demo.entities.Domicilio;

public interface DomicilioService extends BaseService<Domicilio,Long>{
}