package com.example.demo.services;

import com.example.demo.entities.Localidad;

public interface LocalidadService extends BaseService<Localidad,Long> {
}